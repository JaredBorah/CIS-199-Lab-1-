﻿// C5608
// CIS199-75
//Lab 1
// September 2nd, 2018
// This lab shows a basic understanding of some of the tools in C#. 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Grading ID:     C5608");
            Console.WriteLine("Hobbies:        Bowling and Video Games");
            Console.WriteLine("Favorite Book:  The Hunger Games");
            Console.WriteLine("Favorite Movie: Hacksaw Ridge");
        }
    }
}
